    <?php include('header.php');?>
    <div class="slider-area">
        <div class="slider-wrapper owl-carousel">
            <div class="slider-item home-one-slider-otem slider-item-four slider-bg-one">
                <div class="container">
                    <div class="row">
                        <div class="slider-content-area">
                            <div class="slide-text">
                                <h1 class="homepage-three-title"> Website & Mobile App <span class="spn-app"> </span> <span>Development</span> </h1>
                                <h2> Making Brands Come Alive <br /> Website | Mobile App | Digital Marketing </h2>
                                <div class="slider-content-btn"> <a class="button btn btn-light btn-radius btn-brd" href="https://main.solicitous.cloud/candisource2/contact.html#contact" style="margin-top: 10px;">Get In Touch</a>
                                    <!--<a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slider-item home-one-slider-otem slider-item-four slider-bg-two">
                <div class="container">
                    <div class="row">
                        <div class="slider-content-area">
                            <div class="slide-text">
                                <h1 class="homepage-three-title">Candi<span>.AI</span></h1>
                                <h2> Complete Recruitment Solutions, <br /> One Integral Platform. </h2>
                                <div class="slider-content-btn"> <a class="button btn btn-light btn-radius btn-brd" href="https://main.solicitous.cloud/candisource.com/index2.html">Know More</a>
                                    <!--<a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slider-item home-one-slider-otem slider-item-four slider-bg-three">
                <div class="container">
                    <div class="row">
                        <div class="slider-content-area">
                            <div class="slide-text">
                                <h1 class="homepage-three-title"> Staff<span> Augmentation</span> </h1>
                                <h2> Build Amazing Teams, On Demand <br /> Quickly assemble the teams you need,<br> exactly when you need them. </h2>
                                <div class="slider-content-btn"> <a class="button btn btn-light btn-radius btn-brd" href="https://main.solicitous.cloud/candisource2/contact.html#contact">Get In Touch</a>
                                    <!--<a class="button btn btn-light btn-radius btn-brd" href="#">Contact</a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="whats-app-btn">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"> <a href="https://wa.me/9999975795" class="float" target="_blank"> <i class="fa fa-whatsapp my-float"></i> </a>
    </div> <!-- -------about section--------- -->
    <div id="about" class="section wb" style="margin-top:15px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="message-box">
                        <h2 style="color: #fe8101;"> <b> We Love What We Do And Solve Your<br> IT Business Solutions</b> </h2>
                        <p class="lead"> We are a rising IT staffing & software development company that helps organizations, startups, and well-established companies to create incredible IT products, apps, and solutions from start to finish. </p> <a href="services.html" class="btn btn-light btn-radius btn-brd grd1">Know More</a>
                    </div> <!-- end messagebox -->
                </div> <!-- end col -->
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <ul class="features-right">
                        <li class="wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s">
                            <!-- <i class="flaticon-pantone"></i> --> <i class="fa fa-users" aria-hidden="true"></i>
                            <div class="fr-inner">
                                <h4 style="font-weight: bold;">Dedicated Team</h4>
                                <p class="index-right-para">With a predictable and defined budget, Get full control over the management of the team. </p>
                            </div>
                        </li>
                        <li class="wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.3s"> <i class="flaticon-cloud-computing"></i>
                            <div class="fr-inner">
                                <h4 style="font-weight: bold;">Creative Minds</h4>
                                <p> Great creative ideas are like expensive wines. We think out of the box and deliver amazing designs & creativity. </p>
                            </div>
                        </li>
                        <li class="wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.4s"> <i class="flaticon-line-graph"></i>
                            <div class="fr-inner">
                                <h4 style="font-weight: bold;">Business Collaboration</h4>
                                <p> Collaboration is the fuel that allows common people to attain uncommon results. </p>
                            </div>
                        </li>
                    </ul>
                </div> <!-- end col -->
                <!-- end media -->
            </div> <!-- end col -->
        </div> <!-- end media -->
    </div> <!-- end col -->
    </div> <!-- end row -->
    </div> <!-- end container -->
    </div> <!-- end section -->
    <div id="about" class="section-wb-01" style="">
        <div class="container">
            <div class="section-title text-center">
                <h3 class="our-ser">Our Services</h3>
                <p class="lead"> We are one of the most trusted agencies in India, owing to our successful track record in serving our clients with innovative and specialized solutions. </p>
            </div>
            <div class="row text-center">
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="about-item">
                            <div class="about-icon"> <span class="icon icon-display"></span> </div>
                            <div class="about-text">
                                <h3><a href="#">Staff Augmentation</a></h3>
                                <p style="margin-right: 12px;margin-left: 12px; text-align: justify; margin-bottom: 31px;"> At Candi Source, we are ready to augment your team or your client’s team with high quality IT-talent, ranging from entry level to senior level.<br> • Contract<br> • MSP/VMS<br> • Contract to hire<br> • Direct<br> • RPO<br> <br> <br>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="about-item">
                            <div class="about-icon"> <span class="icon icon-database"></span> </div>
                            <div class="about-text">
                                <h3><a href="#">Website Development</a></h3>
                                <p style="margin-right: 12px;margin-left: 12px; text-align: justify;margin-bottom:31px;"> Developing high-level custom websites is our pride and joy. Website is designed and developed for your every need. Each of our custom websites are customized for its specific purpose and user experience. Built from the ground up, the sky is the limit. <br> • Corporate Website<br> • Ecommerce Website<br> • Product/Service Informative Website<br> • Portfolio Website<br> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="about-item">
                            <div class="about-icon"> <span class="fa fa-laptop"></span> </div>
                            <div class="about-text">
                                <h3><a href="#">Digital Marketing </a></h3>
                                <p style="margin-right: 12px;margin-left: 12px; text-align: justify;"> We help brands connect with people more effortlessly, equipping them to navigate consumers and channels better. Our unconventional narratives and story-telling cuts across digital, creative, content, helping brands realize their most daring vision. We are a360-degree marketing Digital Marketing agency that offers the best blend of our deep and intuitive learnings, spanning media, data, insights, and more. <br> SEO • SMO • SMM • PPC </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="about-item">
                            <div class="about-icon"> <span class="fa fa-paint-brush"></span> </div>
                            <div class="about-text">
                                <h3><a href="#">Graphic Designing</a></h3>
                                <p style="margin-right: 12px;margin-left: 12px; text-align: justify;"> We at Candi Source believe that everything in this world starts with a thought and when these thoughts are expressed in a creative manner to create a visual it becomes a design. Graphic designing helps in conveying a specific message (or messages) to a targeted audience. <br> • Logo Designing<br> • Business Stationery Designing<br> • Packaging Designing<br> • Catalogue Designing<br> <br> <br> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="about-item">
                            <div class="about-icon"> <span class="fa fa-mobile"></span> </div>
                            <div class="about-text">
                                <h3><a href="#"> Mobile App Development:</a></h3>
                                <p style="margin-right: 12px;margin-left: 12px; text-align: justify;"> Candi Source develop high quality Native and Hybrid mobile apps for Android, IOS, and Windows platforms. More than half of mobile users browse the Internet on their device, and many of them shop directly from their mobile device. We design beautiful, innovative apps to help you take your business where your customers are. In today’s Mobile First business environment it is critical for businesses to offer a Reliable, Professional and Feature Rich Mobile App to its customers. <br> <br> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="about-item">
                            <div class="about-icon"> <span class="fa fa-globe"></span> </div>
                            <div class="about-text">
                                <h3><a href="#">Web App </a></h3>
                                <p style="margin-right: 12px;margin-left: 12px; text-align: justify;"> Candi Source is among the first-rate web app development companies in Delhi, India, widely known in the B2B circuit for white-label application development and for offering completely managed development services to both budding businesses and established companies alike who want to extend their tech capabilities. Our dedicated team of expert app developers uses their goal-driven skills to leverage advanced tools and tech stack to transform your unique ideas into innovative, scalable, and robust applications. </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </div>
    </div> <!-- end section -->
    <!-- <div class="parallax section noover" data-stellar-background-ratio="0.7" style="margin-top: -70px;">-->
    <div class="container">
        <div class="row text-center">
            <div class="col-md-6" style="margin-bottom:20px">
                <div class="customwidget text-left">
                    <!--<div style="background-image:url('images/Candi-AI-07.png')" style="hight:200px"></div>--> <img src="images/Candi Logo Final-02.png" style="width: 254px; height: 86px; margin-bottom: 15px">
                    <h3 style="color:#ff8100">The secret to successful hiring is:</h3>
                    <ul class="list-inline" style="color: black;">
                        <li style="color: black;"><i class="fa fa-check"></i>Use our AI and machine learning techniques to identify talent faster</li>
                        <li style="color: black;"><i class="fa fa-check"></i> Engage automatically with the candidates.</li>
                        <li style="color: black;"><i class="fa fa-check"></i>Track successful hires and instantaneously search similar candidates</li>
                        <!--<li style="color: #fe8101"><i class="fa fa-check"></i> Content</li>-->
                    </ul> <!-- end list --> <a href="#services" data-scroll="" class="btn btn-light btn-radius btn-brd">Learn More</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="text-center image-center hidden-sm hidden-xs"> <img src="images/Banner candi - ai-17.png" alt="" class="img-responsive wow fadeInUp" /> </div>
                <!--<div class="right-btn"> <a href="">-->
                <!-- <button-->
                <!-- style="display: block; margin: 30px 150px; background: orange; color: #fff; padding: 5px 22px; border-radius: 25px 0px 25px 0px; border: none;"-->
                <!-- type="button">Download Our App</button>-->
                <!-- </a> </div>-->
            </div>
        </div>
    </div> <!-- candi page start -->
    <div class="parallax section parallax-off-01 features-right-bg" data-stellar-background-ratio=""> <!-- style="margin-top: -40px;" -->
        <div class="container">
            <div class="row text-center stat-wrap counter-section-02">
                <div class="col-md-3 col-sm-6 col-xs-6 first-counter"> <span data-scroll="" class="global-radius icon_wrap effect-1"><i class="flaticon-briefcase"></i></span>
                    <div class="stat-count-row">
                        <p class="stat_count">150</p> <span>+</span>
                    </div>
                    <h3>Finished Projects</h3>
                </div> <!-- end col -->
                <div class="col-md-3 col-sm-6 col-xs-6 second-counter"> <span data-scroll="" class="global-radius icon_wrap effect-1"><i class="flaticon-idea"></i></span>
                    <div class="stat-count-row">
                        <p class="stat_count">20</p> <span>+</span>
                    </div>
                    <h3>Years' Experience</h3>
                </div> <!-- end col -->
                <div class="col-md-3 col-sm-6 col-xs-6 third-counter"> <span data-scroll="" class="global-radius icon_wrap effect-1"><i class="flaticon-happy"></i></span>
                    <div class="stat-count-row">
                        <p class="stat_count">130</p><span>+</span>
                    </div>
                    <h3>Happy Clients</h3>
                </div> <!-- end col -->
                <div class="col-md-3 col-sm-6 col-xs-6 fourth-counter"> <span data-scroll="" class="global-radius icon_wrap effect-1"><i class="flaticon-customer-service"></i></span>
                    <div class="stat-count-row">
                        <p class="stat_count">100</p><span>%</span>
                    </div>
                    <h3>Satisfaction</h3>
                </div> <!-- end col -->
            </div> <!-- end row -->
        </div> <!-- end container -->
    </div> <!-- candi page end-------------------------------- -->
    <!-- end section -->
    <section class="testimonials" style="background-image: url(images/abstract-luxury-plain-blur-grey-black-gradient-used-as-background-studio-wall-display-your-products.jpg); background-size: cover; background-repeat: no-repeat; padding-bottom:40px">
        <div class="section-title text-center">
            <div class="heading">
                <h3 class="our-ser">Testimonials</h3>
            </div>
            <p class="lead"> </p>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div id="customers-testimonials" class="owl-carousel">
                        <!--TESTIMONIAL 1 -->
                        <div class="item">
                            <div class="shadow-effect"> <img class="img-circle" src="images/Clients Logo-07.jpeg" alt="">
                                <p>"It is a distinct pleasure for me to recommend CandiSource Technology to any and all interested parties. They have been professional, comprehensive and competent throughout the process of our working together.</p>
                            </div>
                            <div class="testimonial-name">Director</div>
                        </div>
                        <!--END OF TESTIMONIAL 1 -->
                        <!--TESTIMONIAL 2 -->
                        <div class="item">
                            <div class="shadow-effect"> <img class="img-circle" src="images/Clients Logo-08.jpeg" alt="">
                                <p>"I would highly recommend CandiSource Technology. They are great to work with. The traffic to our website has increased thanks to their SEO service.</p>
                            </div>
                            <div class="testimonial-name-01">MD</div>
                        </div>
                        <!--END OF TESTIMONIAL 2 -->
                        <!--TESTIMONIAL 3 -->
                        <div class="item">
                            <div class="shadow-effect"> <img class="img-circle" src="images/Clients Logo-02.jpg" alt="">
                                <p>"Our site is beautiful! It is easy to navigate. The support has been remarkable by the CandiSource team.</p>
                            </div>
                            <div class="testimonial-name">Marketing</div>
                        </div>
                        <!--END OF TESTIMONIAL 3 -->
                        <!--TESTIMONIAL 4 -->
                        <div class="item">
                            <div class="shadow-effect"> <img class="img-circle" src="images/Clients Logo-07.jpeg" alt="">
                                <p>"It is a distinct pleasure for me to recommend CandiSource Technology to any and all interested parties. They have been professional, comprehensive and competent throughout the process of our working together.</p>
                            </div>
                            <div class="testimonial-name">Director</div>
                        </div>
                        <!--END OF TESTIMONIAL 4 -->
                        <!--TESTIMONIAL 5 -->
                        <div class="item">
                            <div class="shadow-effect"> <img class="img-circle" src="images/Clients Logo-08.jpeg" alt="">
                                <p>"I would highly recommend CandiSource Technology. They are great to work with. The traffic to our website has increased thanks to their SEO service.</p>
                            </div>
                            <div class="testimonial-name-01">MD</div>
                        </div>
                        <!--END OF TESTIMONIAL 5 -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!------------------------------------------------testo end---------------------------------------->
    <!-- end section -->
    <section style="background-image: url(images/Banners1111.png); background-repeat: no-repeat; background-size: cover; padding-bottom:80px">
        <div class="text">
            <h3 style="color: orange; font-size: 43px; font-weight:600; padding-top:50px">Our Clients</h3>
        </div>
        <div class="container" style="margin-top: 15px;margin-bottom: 0px;">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="carousel carousel-showmanymoveone slide" id="itemslider">
                        <div class="carousel-inner">
                            <div class="item active">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/Clients Logo-01.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/Clients Logo-02.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/Clients Logo-03.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/Clients Logo-04.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/Clients Logo-05.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/Clients Logo-06.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/Clients Logo-07.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/iqvia.png" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/logo-02.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                            <div class="item">
                                <div class="col-xs-12 col-sm-6 col-md-2"> <a href="#"><img src="images/logo-01.jpg" class="img-responsive center-block"></a> </div>
                            </div>
                        </div>
                        <div id="slider-control"> <a class="left carousel-control" href="#itemslider" data-slide="prev"><img src="https://cdn0.iconfinder.com/data/icons/website-kit-2/512/icon_402-512.png" alt="Left" class="img-responsive"></a> <a class="right carousel-control" href="#itemslider" data-slide="next"><img src="http://pixsector.com/cache/81183b13/avcc910c4ee5888b858fe.png" alt="Right" class="img-responsive"></a> </div>
                    </div>
                </div>
            </div>
        </div>
    </section> <!-- end section -->
    <!--end our services-->
    <!-- end section -->
    <!------------------------------------------------------------------footer start------------------------------------------->
    <?php include('footer.php');?>
    